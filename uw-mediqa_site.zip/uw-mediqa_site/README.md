
# UW MediQA
Team members:  
* William R. Kearns
* Wilson Lau  
* Jason Thomas

Project page: https://kearnsw.github.io/uw-mediqa


